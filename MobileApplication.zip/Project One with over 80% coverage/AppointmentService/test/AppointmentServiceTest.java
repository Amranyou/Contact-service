/*
 * Author: Fathi Amran
 */

package test;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import app.Appointment;
import app.AppointmentService;

class AppointmentServiceTest {

	@Test
	void testAddAppointment() throws ParseException {
		// new object to test using AppointmentService.addAppointment()
		Appointment appointment = AppointmentService.addAppointment("12345", "09-08-2022", "Discuss lifestyle changes");

		assertEquals("12345", appointment.getID());									// test ID
		assertEquals("09-08-2022", appointment.getAppointmentDate());				// test date
		assertEquals("Discuss lifestyle changes", appointment.getDescription());	// test description
	}
	
	@Test
	void testDeleteAppointment() throws Exception {
		// delete Appointment
		// NOTE: Appointment ID 12345 was created in AppointmentService.addAppointment()
		// Change the appointment ID to a non-existing ID and an exception will be thrown
		AppointmentService.deleteAppoitnment("12345");
	}
	
	@Test
	void testIdNotFound() {
		// expecting an exception for ID not found when deleting an appointment
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			AppointmentService.deleteAppoitnment("12F345");
		}); 
	}

}
