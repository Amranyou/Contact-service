/*
 * Author: Fathi Amran
 */

package test;

import static org.junit.jupiter.api.Assertions.*;
import java.text.ParseException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import app.Appointment;

class AppointmentTest {

	@Test
	void testAppointmentAttributes() throws ParseException {

		// new object to test
		Appointment appointment = new Appointment("123", "09-08-2022", "Discuss lifestyle changes");

		assertEquals("123", appointment.getID());								// test ID
		assertEquals("09-08-2022", appointment.getAppointmentDate());			// test appointment date
		assertEquals("Discuss lifestyle changes", appointment.getDescription());	// test description
	}
	
	@Test
	void testUniqueID() {
		// the appointment being created has the same ID as the the one we created in the testAppointmentAttributes()
		// We are expected this test to throw an exception that the ID is duplicate
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("123", "09-08-2022", "Discuss lifestyle changes");
		}); 
	}
	
	@Test
	void testIDLength() {
		// expecting an exception for ID longer than 10 characters
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345678911145643", "09-08-2022", "Discuss lifestyle changes");
		}); 
	}
	
	@Test
	void testPastDate() {
		// expecting an exception for dates that are in the past
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", "01-04-2004", "Discuss lifestyle changes");
		}); 
	}
	
	@Test
	void testDescriptionLength() {
		// expecting an exception for description longer than 50 characters
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("123456789", "09-08-2022", "Description is longer than 50 characters. More text");
		}); 
	}
}
