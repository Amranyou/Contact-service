/*
 * Author: Fathi Amran
 */

package app;

import java.text.ParseException;
import java.util.Vector;

public class AppointmentService {
	
	// add appointment
	public static Appointment addAppointment(String ID, String appointmentDate, String description) throws ParseException {
		Appointment appointment = new Appointment(ID, appointmentDate, description);
		return appointment;
	}
	
	// delete appointment
	public static void deleteAppoitnment(String ID) throws Exception {
		// access vector of Tasks
		Vector<Appointment> appointments = Appointment.appointmentIDs;
		
		// find Appointment by ID
		for(int i = 0; i < appointments.size(); ++i) {
			if(appointments.get(i).getID() == ID) {
				// delete object from vector so that
				// the garbage collector can free memory
				appointments.remove(i);
				return;
			}
		}
		// throw exception that ID was not found
		throw new IllegalArgumentException("ID not found");
	}

}
