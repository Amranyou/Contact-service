/*
 * Author: Fathi Amran
 */

package app;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

public class Appointment {
	
	// attributes
	private final String ID;
	public String appointmentDate;
	public String description;
	
	// vector stores all the Appointments that are being created
	// the purpose of this is to detect duplicate IDs
	public static Vector<Appointment> appointmentIDs = new Vector<Appointment>();
	
	// constructor to create a Appointment
	public Appointment(String ID, String appointmentDate, String description) throws ParseException {
		
		// check if the ID is null or greater than 10 characters
		if(ID.length() > 10 || null == ID) {
			// throw exception
			throw new IllegalArgumentException("ID cannot be null or greater than 10 characters");
		} else {
			// check ID for duplicates
			for(int i = 0; i < appointmentIDs.size(); ++i) {
				if(appointmentIDs.get(i).getID() == ID) {
					throw new IllegalArgumentException("ID already exists. It has to be unique");
				}
			}
			
			// everything checks out
			this.ID = ID;
		}
		
		// check if the date is null
		if(null == appointmentDate) {
			// date is null
			throw new IllegalArgumentException("Appointment date cannot be null");
		} else {
			// create date format
		    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");      
		    // parsing the given String to Date object
		    Date date = formatter.parse(appointmentDate);
		    // current date
		    Date currentDate = new Date();
		    		    
		    // check if date is in the past
		    if(date.before(currentDate)) {
		    	// date in the past
		    	throw new IllegalArgumentException("Appointment date cannot be in the past");
		    } 
		    else {
				// everything checks out
				this.appointmentDate = appointmentDate;
		    }
		}
		
		// check if description is null or greater than 50 characters
		if(null == description || description.length() > 50) {
			// throw exception
			throw new IllegalArgumentException("Description cannot be null or greater than 50 characters");
		} else {
			// everything checks out
			this.description = description;
		}
		
		// add Appointment to vector
		appointmentIDs.add(this);
	}
	
	
	// getters
	public String getID() {
		return this.ID;
	}
	
	public String getAppointmentDate() {
		return this.appointmentDate;
	}
	
	public String getDescription() {
		return this.description;
	}

}
