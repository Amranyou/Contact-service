/*
 * Author: Fathi Amran
 */

package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Vector;

import org.junit.jupiter.api.Test;

import app.Task;
import app.TaskService;

class TaskServiceTest {

	@Test
	void testAddTask() {
		// new object to test using TaskService.addTask()
		Task task = TaskService.addTask("12345", "Check email", "Checks emails for spam");

		assertEquals("12345", task.getID());								// test ID
		assertEquals("Check email", task.getName());					// test name
		assertEquals("Checks emails for spam", task.getDescription());	// test description
	}
	
	@Test
	void testUpdateTask() throws Exception {
		// access vector of Tasks
		Vector<Task> tasks = Task.taskIDs;
		// temporary Task to hold the Task being updated
		Task task = null;
		
		/*
		 * In this test, we are updating a task using ID 12345, which
		 * was created in TaskService.addTask()
		 * I used a variable to reference the ID because it is being used in multiple 
		 * lines inside this method
		 */
		// ID to update
		String IDToUpdate = "12345";
		
		// update task using TaskService.updateTask()
		// Change the task ID to a non-existing ID and an exception will be thrown
		TaskService.updateTask(IDToUpdate, "Updated Name", "Updated Description");
		
		// loop through the vector of task to find the Task being updated
		for(int i = 0; i < tasks.size(); ++i) {
			if(tasks.get(i).getID() == IDToUpdate) {
				// get the Task being updated
				task = tasks.get(i);
			}
		}
		// check if update took effect
		assertEquals("Updated Name", task.getName());				// test name
		assertEquals("Updated Description", task.getDescription());	// test description
	}
	
	@Test
	void testDeleteTask() throws Exception {
		// delete Task
		// NOTE: task ID 12345 was created in TaskService.addTask()
		// Change the task ID to a non-existing ID and an exception will be thrown
		TaskService.deleteTask("12345");
	}

}
