/*
 * Author: Fathi Amran
 */

package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import app.Task;

class TaskTest {

	@Test
	void testTaskAttributes() {
		
		// new object to test
		Task task = new Task("123", "Check email", "Checks emails for spam");

		assertEquals("123", task.getID());								// test ID
		assertEquals("Check email", task.getName());					// test name
		assertEquals("Checks emails for spam", task.getDescription());	// test description
	}
	
	@Test
	void testUniqueID() {
		// the task being created has the same ID as the the one we created in the testTaskAttributes()
		// We are expected this test to throw an exception that the ID is duplicate
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", "Check email", "Checks emails for spam");
		}); 
	}
	
	@Test
	void testIDLength() {
		// expecting an exception for long attribute names
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345678911145643", "Do something", "Description is short");
		}); 
	}
	
	@Test
	void testNameLength() {
		// expecting an exception for long attribute names
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1234567890", "Name is larger than 20 characters", "Description is short");
		}); 
	}
	
	@Test
	void testDescriptionLength() {
		// expecting an exception for long attribute names
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123456789", "Name", "Description is longer than 50 characters. More text");
		}); 
	}
}
