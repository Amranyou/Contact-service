/*
 * Author: Fathi Amran
 */

package app;

import java.util.Vector;

public class Task {
	
	// attributes
	private final String ID;
	public String name;
	public String description;
	
	// vector stores all the tasks that are being created
	// the purpose of this is to detect duplicate IDs
	public static Vector<Task> taskIDs = new Vector<Task>();
	
	// constructor to create a Task
	public Task(String ID, String name, String description) {
		
		// check if the ID is null or greater than 10 characters
		if(ID.length() > 10 || null == ID) {
			// throw exception
			throw new IllegalArgumentException("ID cannot be null or greater than 10 characters");
		} else {
			// check ID for duplicates
			for(int i = 0; i < taskIDs.size(); ++i) {
				if(taskIDs.get(i).getID() == ID) {
					throw new IllegalArgumentException("ID already exists. It has to be unique");
				}
			}
			
			// everything checks out
			this.ID = ID;
		}
		
		// check if the name is null or greater than 20 characters
		if(null == name || name.length() > 20) {
			// throw exception
			throw new IllegalArgumentException("Name cannot be null or greater than 20 characters");
		} else {
			// everything checks out
			this.name = name;
		}
		
		// check if description is null or greater than 50 characters
		if(null == description || description.length() > 50) {
			// throw exception
			throw new IllegalArgumentException("Name cannot be null or greater than 20 characters");
		} else {
			// everything checks out
			this.description = description;
		}
		
		// add Task to vector
		taskIDs.add(this);
	}
	
	
	// getters
	public String getID() {
		return this.ID;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getDescription() {
		return this.description;
	}

}
