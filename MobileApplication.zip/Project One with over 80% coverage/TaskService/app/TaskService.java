/*
 * Author: Fathi Amran
 */

package app;

import java.util.Vector;

public class TaskService {
	
	public static Task addTask(String ID, String name, String description) {
		Task task = new Task(ID, name, description);
		return task;
	}
	
	public static void updateTask(String ID, String name, String description) throws Exception {
		// access vector of Tasks
		Vector<Task> tasks = Task.taskIDs;
		
		for(int i = 0; i < tasks.size(); ++i) {
			if(tasks.get(i).getID() == ID) {
				// update name and description
				tasks.get(i).name = name;
				tasks.get(i).description = description;
			}
		}
	}
	
	public static void deleteTask(String ID) throws Exception {
		// access vector of Tasks
		Vector<Task> tasks = Task.taskIDs;
		
		// find Task by ID
		for(int i = 0; i < tasks.size(); ++i) {
			if(tasks.get(i).getID() == ID) {
				// delete object from vector so that
				// the garbage collector can free memory
				tasks.remove(i);
				return;
			}
		}
		// throw exception that ID was not found
		throw new IllegalArgumentException("ID not found");
	}

}
